import uuid
from datetime import UTC, datetime

import httpx
from pymongo import MongoClient

from config.settings import get_settings


def main() -> int:
    settings = get_settings()
    client = MongoClient(settings.effective_mongodb_uri)
    db = client[settings.effective_database_name]

    registrations = db["registrations"]
    users = db["users"]

    suffix = uuid.uuid4().hex[:8]
    numeric_seed = str(abs(hash(suffix)) % 1000000000).zfill(9)
    mobile = f"9{numeric_seed}"
    order_id = f"SMOKE_IND_ORDER_{suffix}"
    email = f"individual.{suffix}@example.com"

    now = datetime.now(UTC)

    try:
        registrations.insert_one(
            {
                "cf_order_id": order_id,
                "registrationCompleted": False,
                "email": email,
                "fullName": f"Smoke Individual {suffix}",
                "participationMode": "individual",
                "mobile": mobile,
                "project_selected": "Complete App Creation",
                "task_selected": "Complete App Creation",
                "participant_id": f"TEMP_{suffix}",
                "payment": {
                    "gateway": "cashfree",
                    "status": "created",
                    "transaction_id": f"MOCKPAY_{suffix}",
                    "amount": 1800.0,
                    "currency": "INR",
                    "mock_mode": True,
                    "timestamp": now,
                },
                "createdAt": now,
                "updatedAt": now,
            }
        )

        with httpx.Client(base_url="http://127.0.0.1:8010", timeout=30.0) as api:
            verify = api.post(
                "/api/payment/verify",
                json={"cf_order_id": order_id, "cf_payment_id": f"MOCKPAY_{suffix}"},
            )
            print("VERIFY_STATUS", verify.status_code)
            print("VERIFY_BODY", verify.json())
            verify.raise_for_status()

            payload = {
                "fullName": f"Smoke Individual {suffix}",
                "email": email,
                "mobile": mobile,
                "branch": "CSE",
                "collegeName": "Other",
                "otherCollegeName": "smoke individual college",
                "city": "Bengaluru",
                "rollNumber": f"INDROLL{suffix}",
                "githubProfile": f"https://www.github.com/smokeindividual{suffix}",
                "projectSelected": "Complete App Creation",
                "participationMode": "individual",
                "isTeamLeader": False,
                "payment_gateway": "cashfree",
                "cf_payment_id": f"MOCKPAY_{suffix}",
                "cf_order_id": order_id,
                "payment_amount": 1800.0,
            }

            register = api.post("/api/register", json=payload)
            print("REGISTER_STATUS", register.status_code)
            register_body = register.json()
            print("REGISTER_BODY", register_body)
            register.raise_for_status()

            summary = api.get(f"/api/registration/{order_id}/summary")
            print("SUMMARY_STATUS", summary.status_code)
            summary_body = summary.json()
            print("SUMMARY_BODY", summary_body)
            summary.raise_for_status()

        reg_doc = registrations.find_one({"cf_order_id": order_id}, {"_id": 0})

        print("DB_REG_TASK", reg_doc.get("task_selected") if reg_doc else None)
        print("DB_REG_CHALLENGE", (reg_doc or {}).get("assigned_challenge", {}).get("title"))

        if not reg_doc or not reg_doc.get("assigned_challenge"):
            raise RuntimeError("assigned_challenge missing in registrations for individual flow")

        print("SMOKE_RESULT", "PASS")
        return 0
    finally:
        registrations.delete_many({"cf_order_id": order_id})
        users.delete_many({"email": email})


if __name__ == "__main__":
    raise SystemExit(main())
