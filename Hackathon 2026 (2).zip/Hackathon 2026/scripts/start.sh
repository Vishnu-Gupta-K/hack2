#!/usr/bin/env bash
set -euo pipefail

APP_MODULE="app.main:app"
WORKERS="${WORKERS:-2}"
HOST="${SERVER_HOST:-0.0.0.0}"
PORT="${SERVER_PORT:-8000}"

exec gunicorn \
  -k uvicorn.workers.UvicornWorker \
  --workers "${WORKERS}" \
  --bind "${HOST}:${PORT}" \
  --timeout 120 \
  --access-logfile - \
  --error-logfile - \
  "${APP_MODULE}"
