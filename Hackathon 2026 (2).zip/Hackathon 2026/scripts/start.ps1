$ErrorActionPreference = 'Stop'

$appModule = 'app.main:app'
$workers = if ($env:WORKERS) { $env:WORKERS } else { '2' }
$host = if ($env:SERVER_HOST) { $env:SERVER_HOST } else { '0.0.0.0' }
$port = if ($env:SERVER_PORT) { $env:SERVER_PORT } else { '8000' }

python -m uvicorn `
  $appModule
