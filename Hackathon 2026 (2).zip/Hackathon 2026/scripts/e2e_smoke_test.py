import uuid
from datetime import UTC, datetime

import httpx
from pymongo import MongoClient

from config.settings import get_settings


def main() -> int:
    settings = get_settings()
    client = MongoClient(settings.effective_mongodb_uri)
    db = client[settings.effective_database_name]

    registrations = db["registrations"]
    teams = db["teams"]
    users = db["users"]

    suffix = uuid.uuid4().hex[:8]
    numeric_seed = str(abs(hash(suffix)) % 1000000000).zfill(9)
    leader_mobile = f"9{numeric_seed}"
    member_mobile = f"8{numeric_seed}"
    order_id = f"SMOKE_ORDER_{suffix}"
    leader_email = f"leader.{suffix}@example.com"
    member_email = f"member.{suffix}@example.com"

    now = datetime.now(UTC)
    team_id = None

    try:
        registrations.insert_one(
            {
                "cf_order_id": order_id,
                "registrationCompleted": False,
                "email": leader_email,
                "fullName": f"Smoke Leader {suffix}",
                "participationMode": "team",
                "mobile": leader_mobile,
                "totalMembers": 2,
                "project_selected": "Bug Hunt",
                "task_selected": "Bug Hunt",
                "payment": {
                    "gateway": "cashfree",
                    "status": "created",
                    "transaction_id": f"MOCKPAY_{suffix}",
                    "amount": 3000.0,
                    "currency": "INR",
                    "mock_mode": True,
                    "timestamp": now,
                },
                "createdAt": now,
                "updatedAt": now,
            }
        )

        with httpx.Client(base_url="http://127.0.0.1:8010", timeout=30.0) as api:
            verify = api.post(
                "/api/payment/verify",
                json={"cf_order_id": order_id, "cf_payment_id": f"MOCKPAY_{suffix}"},
            )
            print("VERIFY_STATUS", verify.status_code)
            print("VERIFY_BODY", verify.json())
            verify.raise_for_status()

            payload = {
                "fullName": f"Smoke Leader {suffix}",
                "email": leader_email,
                "mobile": leader_mobile,
                "branch": "CSE",
                "collegeName": "Other",
                "otherCollegeName": "smoke test college",
                "city": "Bengaluru",
                "rollNumber": f"ROLL{suffix}",
                "githubProfile": f"https://www.github.com/smokeleader{suffix}",
                "projectSelected": "Bug Hunt",
                "participationMode": "team",
                "isTeamLeader": True,
                "teamName": f"Smoke Team {suffix}",
                "teamMembers": [
                    {
                        "fullName": f"Smoke Member {suffix}",
                        "email": member_email,
                        "mobile": member_mobile,
                        "rollNumber": f"MROLL{suffix}",
                        "githubProfile": f"https://www.github.com/smokemember{suffix}",
                    }
                ],
                "payment_gateway": "cashfree",
                "cf_payment_id": f"MOCKPAY_{suffix}",
                "cf_order_id": order_id,
                "payment_amount": 3000.0,
            }

            register = api.post("/api/register", json=payload)
            print("REGISTER_STATUS", register.status_code)
            register_body = register.json()
            print("REGISTER_BODY", register_body)
            register.raise_for_status()
            team_id = register_body.get("teamId")

            summary = api.get(f"/api/registration/{order_id}/summary")
            print("SUMMARY_STATUS", summary.status_code)
            summary_body = summary.json()
            print("SUMMARY_BODY", summary_body)
            summary.raise_for_status()

        reg_doc = registrations.find_one({"cf_order_id": order_id}, {"_id": 0})
        team_doc = teams.find_one({"teamId": team_id}, {"_id": 0}) if team_id else None

        print("DB_REG_TASK", reg_doc.get("task_selected") if reg_doc else None)
        print("DB_REG_CHALLENGE", (reg_doc or {}).get("assigned_challenge", {}).get("title"))
        print("DB_TEAM_ID", (team_doc or {}).get("teamId"))
        print("DB_TEAM_CHALLENGE", (team_doc or {}).get("assignedChallenge", {}).get("title"))

        if not reg_doc or not reg_doc.get("assigned_challenge"):
            raise RuntimeError("assigned_challenge missing in registrations")
        if not team_doc or not team_doc.get("assignedChallenge"):
            raise RuntimeError("assignedChallenge missing in teams")

        print("SMOKE_RESULT", "PASS")
        return 0
    finally:
        if team_id:
            teams.delete_many({"teamId": team_id})
        registrations.delete_many({"cf_order_id": order_id})
        users.delete_many({"email": leader_email})


if __name__ == "__main__":
    raise SystemExit(main())
