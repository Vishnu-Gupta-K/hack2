from fastapi import APIRouter, HTTPException, status
from fastapi.responses import Response

from app.database.mongodb import colleges_async_collection, registrations_async_collection
from app.models.schemas import (
    DuplicateCheck,
    RegistrationSummaryResponse,
    StudentRegister,
    StudentResponse,
)
from app.services.challenge_service import get_registration_summary
from app.services.payment_service import verify_cashfree_payment
from app.services.receipt_service import build_receipt_pdf, verify_receipt_token
from app.services.registration_service import register_student as register_student_service

router = APIRouter(tags=["students"])


async def resolve_college_name(student: StudentRegister) -> str:
    selected_college = (student.collegeName or "").strip()
    if not selected_college:
        raise HTTPException(status_code=400, detail="College selection is required")

    if selected_college.lower() == "other":
        manual_college = (student.otherCollegeName or "").strip().lower()
        if not manual_college:
            raise HTTPException(status_code=400, detail="Please enter your college name when selecting Other")
        return manual_college

    existing = await colleges_async_collection.find_one(
        {"name_lc": selected_college.lower()},
        {"_id": 0, "name": 1},
    )
    if not existing:
        raise HTTPException(status_code=400, detail="Invalid college selected")
    return str(existing.get("name", selected_college)).strip()


@router.get("/api/check-email/{email}")
async def check_email_exists(email: str):
    normalized_email = email.lower()
    existing = await registrations_async_collection.find_one(
        {
            "registrationCompleted": True,
            "$or": [
                {"email": normalized_email},
                {"leader.email": normalized_email},
                {"team_members.email": normalized_email},
            ],
        },
        {"_id": 1},
    )
    return {"exists": existing is not None}


@router.get("/api/check-roll-number/{roll_number}")
async def check_roll_number_exists(roll_number: str):
    existing = await registrations_async_collection.find_one(
        {
            "registrationCompleted": True,
            "$or": [
                {"rollNumber": roll_number},
                {"leader.rollNumber": roll_number},
                {"team_members.rollNumber": roll_number},
            ],
        },
        {"_id": 1},
    )
    if existing:
        return {"exists": True, "message": "Already exists."}
    return {"exists": False}


@router.get("/api/check-github/{github_profile:path}")
async def check_github_exists(github_profile: str):
    existing = await registrations_async_collection.find_one(
        {
            "registrationCompleted": True,
            "$or": [
                {"githubProfile": github_profile},
                {"leader.githubProfile": github_profile},
                {"team_members.githubProfile": github_profile},
            ],
        },
        {"_id": 1},
    )
    if existing:
        return {"exists": True, "message": "Already exists."}
    return {"exists": False}


@router.post("/api/check-duplicate")
async def check_duplicate(data: DuplicateCheck):
    checks = []
    normalized_email = data.email.lower() if data.email else None

    if normalized_email and await registrations_async_collection.find_one(
        {
            "registrationCompleted": True,
            "$or": [
                {"email": normalized_email},
                {"leader.email": normalized_email},
                {"team_members.email": normalized_email},
            ],
        },
        {"_id": 1},
    ):
        checks.append({"field": "email", "exists": True, "message": "This email is already registered."})

    if data.rollNumber and await registrations_async_collection.find_one(
        {
            "registrationCompleted": True,
            "$or": [
                {"rollNumber": data.rollNumber},
                {"leader.rollNumber": data.rollNumber},
                {"team_members.rollNumber": data.rollNumber},
            ],
        },
        {"_id": 1},
    ):
        checks.append({"field": "rollNumber", "exists": True, "message": "Already exists."})

    if data.githubProfile and await registrations_async_collection.find_one(
        {
            "registrationCompleted": True,
            "$or": [
                {"githubProfile": data.githubProfile},
                {"leader.githubProfile": data.githubProfile},
                {"team_members.githubProfile": data.githubProfile},
            ],
        },
        {"_id": 1},
    ):
        checks.append({"field": "githubProfile", "exists": True, "message": "Already exists."})

    return {"hasDuplicate": len(checks) > 0, "duplicates": checks}


@router.post("/api/register", response_model=StudentResponse, status_code=status.HTTP_201_CREATED)
async def register_student(student: StudentRegister):
    resolved_college_name = await resolve_college_name(student)
    student = student.model_copy(update={"collegeName": resolved_college_name})

    if not student.cf_order_id:
        raise HTTPException(status_code=400, detail="Payment details are missing. Please complete the payment first.")

    try:
        verified_payment = await verify_cashfree_payment(student.cf_order_id, student.cf_payment_id)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Payment verification error: {exc}")

    cf_payment_id = (
        verified_payment.get("cf_payment_id")
        or verified_payment.get("payment_id")
        or verified_payment.get("paymentId")
    )
    payment_status = str(verified_payment.get("payment_status", "SUCCESS"))

    return await register_student_service(student, cf_payment_id, payment_status)


@router.get("/api/registration/{registration_id}/summary", response_model=RegistrationSummaryResponse)
async def registration_summary(registration_id: str):
    return await get_registration_summary(registration_id)


@router.get("/api/all-users-json")
async def get_all_users_json():
    cursor = registrations_async_collection.find({"registrationCompleted": True})
    registrations = await cursor.to_list(length=1000)
    
    flattened_users = []
    for reg in registrations:
        # Participation Mode
        mode = reg.get("participationMode", "individual")
        
        # Base data from registration
        common_data = {
            "registrationId": reg.get("cf_order_id"),
            "participationMode": mode,
            "teamId": reg.get("team_id"),
            "teamName": reg.get("team_name"),
            "projectSelected": reg.get("project_selected"),
            "is_reviewed": reg.get("is_reviewed", False),
            "is_selected": reg.get("is_selected", False),
            "Reviewedby": reg.get("Reviewedby"),
            "user_feedback": reg.get("user_feedback"),
            "registeredAt": reg.get("registeredAt"),
            "paymentStatus": reg.get("payment_status"),
        }
        
        # Leader data
        leader = reg.get("leader", {})
        leader_entry = {
            **common_data,
            "role": "leader" if mode == "team" else "individual",
            "participantId": leader.get("participant_id"),
            "fullName": leader.get("name"),
            "email": leader.get("email"),
            "mobile": leader.get("phone"),
            "collegeName": leader.get("college"),
            "branch": leader.get("branch"),
            "city": leader.get("city"),
            "rollNumber": leader.get("rollNumber"),
            "githubProfile": leader.get("githubProfile"),
        }
        flattened_users.append(leader_entry)
        
        # Team members data
        for member in reg.get("team_members", []):
            member_entry = {
                **common_data,
                "role": "member",
                "participantId": member.get("participant_id"),
                "fullName": member.get("name"),
                "email": member.get("email"),
                "mobile": member.get("mobile"),
                "collegeName": leader.get("college"), # members share leader's college in current schema
                "branch": member.get("branch") or leader.get("branch"),
                "city": leader.get("city"),
                "rollNumber": member.get("rollNumber"),
                "githubProfile": member.get("githubProfile"),
            }
            flattened_users.append(member_entry)
            
    return flattened_users


@router.get("/api/receipt/{registration_id}")
async def download_receipt(registration_id: str, email: str, token: str):
    if not verify_receipt_token(token=token, registration_id=registration_id, email=email):
        raise HTTPException(status_code=403, detail="Invalid receipt token")

    registration = await registrations_async_collection.find_one({"cf_order_id": registration_id})
    if not registration:
        raise HTTPException(status_code=404, detail="Registration not found")

    leader_email = str(registration.get("leader", {}).get("email", "")).lower()
    member_emails = {str(item.get("email", "")).lower() for item in registration.get("team_members", [])}
    requested_email = email.lower()
    if requested_email != leader_email and requested_email not in member_emails:
        raise HTTPException(status_code=403, detail="Email is not authorized for this receipt")

    pdf_data = build_receipt_pdf(registration, requested_email)
    return Response(
        content=pdf_data,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="Spheronix_Receipt_{registration_id}.pdf"',
            "Cache-Control": "no-store",
        },
    )