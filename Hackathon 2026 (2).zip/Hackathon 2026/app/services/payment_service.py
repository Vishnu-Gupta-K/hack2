import logging
import secrets
import hashlib

from fastapi import HTTPException
from pymongo.errors import DuplicateKeyError

from app.core.time_utils import ist_now, unix_timestamp, utc_now
from app.database.mongodb import registrations_async_collection
from app.models.schemas import PaymentOrderRequest, PaymentOrderResponse
from app.services.cashfree_client import CashfreeAPIError, CashfreeClient
from config.settings import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

cashfree_client = CashfreeClient(
    app_id=settings.cashfree_app_id,
    secret_key=settings.cashfree_secret_key,
    environment=settings.cashfree_environment,
)


async def verify_cashfree_payment(order_id: str, payment_id: str | None = None) -> dict:
    payment_doc = await registrations_async_collection.find_one(
        {"cf_order_id": order_id},
        {"_id": 0, "payment.mock_mode": 1, "payment.transaction_id": 1},
    )
    payment_state = payment_doc.get("payment", {}) if payment_doc else {}
    if payment_state.get("mock_mode"):
        mock_payment_id = payment_id or payment_state.get("transaction_id") or f"MOCKPAY_{order_id[-8:]}"
        return {
            "cf_payment_id": mock_payment_id,
            "payment_status": "SUCCESS",
            "mock_mode": True,
        }

    payments_response = await cashfree_client.fetch_order_payments(order_id)
    payments = payments_response if isinstance(payments_response, list) else payments_response.get("payments", [])
    if not payments:
        raise HTTPException(status_code=400, detail="Payment not found for the given order")

    target_payment = None
    for item in payments:
        item_id = item.get("cf_payment_id") or item.get("payment_id") or item.get("paymentId")
        if payment_id and item_id == payment_id:
            target_payment = item
            break

    if target_payment is None:
        target_payment = payments[0]

    status_value = str(target_payment.get("payment_status", "")).upper()
    if status_value != "SUCCESS":
        raise HTTPException(status_code=400, detail=f"Payment is not successful. Current status: {status_value or 'UNKNOWN'}")

    return target_payment


async def create_order(request: PaymentOrderRequest) -> PaymentOrderResponse:
    normalized_email = str(request.email).lower()
    selected_task = (request.projectSelected or '').strip()

    existing_registration = await registrations_async_collection.find_one(
        {"email": normalized_email},
        {"_id": 1, "registrationCompleted": 1},
    )
    if existing_registration and existing_registration.get("registrationCompleted"):
        raise HTTPException(status_code=409, detail="This email is already registered for the hackathon")

    base_amount = 1800
    if request.participationMode == "team":
        total_members = 1 + request.teamMembersCount
        amount = base_amount * total_members
    else:
        amount = base_amount

    cf_order_id = f"CF_{unix_timestamp()}_{secrets.token_hex(4)}"
    customer_id = f"cust_{hashlib.sha256(str(request.email).lower().encode('utf-8')).hexdigest()[:16]}"

    try:
        order = await cashfree_client.create_order(
            order_id=cf_order_id,
            order_amount=float(amount),
            customer_id=customer_id,
            customer_name=request.fullName,
            customer_email=str(request.email),
            customer_phone=request.mobile,
        )

        total_members = 1 + request.teamMembersCount if request.participationMode == "team" else 1
        update_filter = {"email": normalized_email}
        if existing_registration and existing_registration.get("_id") is not None:
            update_filter = {"_id": existing_registration["_id"]}

        await registrations_async_collection.update_one(
            update_filter,
            {
                "$set": {
                    "cf_order_id": cf_order_id,
                    "registrationCompleted": False,
                    "email": normalized_email,
                    "fullName": request.fullName,
                    "participationMode": request.participationMode,
                    "mobile": request.mobile,
                    "totalMembers": total_members,
                    "project_selected": selected_task or None,
                    "task_selected": None,
                    "payment": {
                        "gateway": "cashfree",
                        "status": "created",
                        "transaction_id": None,
                        "amount": float(amount),
                        "currency": "INR",
                        "timestamp": ist_now(),
                    },
                    "updatedAt": ist_now(),
                    "registeredAt": None,
                    "is_reviewed": False,
                    "is_selected": False,
                    "Reviewedby": None,
                    "user_feedback": None,
                    "password": "",
                    "feedback": "",
                    "github_link": "",
                },
                "$setOnInsert": {
                    "createdAt": ist_now(),
                },
            },
            upsert=True,
        )

        return PaymentOrderResponse(
            orderId=order["order_id"],
            amount=float(amount),
            currency="INR",
            paymentSessionId=order["payment_session_id"],
            paymentGateway="cashfree",
            environment=settings.cashfree_environment,
        )
    except CashfreeAPIError as exc:
        logger.error("Cashfree order creation failed: %s", exc)
        error_text = str(exc).lower()
        if settings.cashfree_allow_mock_on_block and exc.status_code == 403 and "ip" in error_text and "allow" in error_text:
            mock_order_id = f"MOCK_CF_{unix_timestamp()}_{secrets.token_hex(3)}"
            mock_payment_id = f"MOCK_PAY_{secrets.token_hex(6)}"
            total_members = 1 + request.teamMembersCount if request.participationMode == "team" else 1

            update_filter = {"email": normalized_email}
            if existing_registration and existing_registration.get("_id") is not None:
                update_filter = {"_id": existing_registration["_id"]}

            await registrations_async_collection.update_one(
                update_filter,
                {
                    "$set": {
                        "cf_order_id": mock_order_id,
                        "registrationCompleted": False,
                        "email": normalized_email,
                        "fullName": request.fullName,
                        "participationMode": request.participationMode,
                        "mobile": request.mobile,
                        "totalMembers": total_members,
                        "project_selected": selected_task or None,
                        "task_selected": None,
                        "payment": {
                            "gateway": "cashfree",
                            "status": "created",
                            "transaction_id": mock_payment_id,
                            "amount": float(amount),
                            "currency": "INR",
                            "mock_mode": True,
                            "timestamp": ist_now(),
                        },
                        "updatedAt": ist_now(),
                        "registeredAt": None,
                        "is_reviewed": False,
                        "is_selected": False,
                        "Reviewedby": None,
                        "user_feedback": None,
                        "password": "",
                        "feedback": "",
                        "github_link": "",
                    },
                    "$setOnInsert": {
                        "createdAt": ist_now(),
                    },
                },
                upsert=True,
            )

            return PaymentOrderResponse(
                orderId=mock_order_id,
                amount=float(amount),
                currency="INR",
                paymentSessionId="MOCK_SESSION",
                paymentGateway="cashfree",
                environment=settings.cashfree_environment,
                mockMode=True,
                mockPaymentId=mock_payment_id,
                message="Cashfree IP allowlist blocked this request. Mock payment mode enabled for local testing.",
            )

        raise HTTPException(status_code=exc.status_code, detail=str(exc))
    except DuplicateKeyError as exc:
        logger.exception("Mongo duplicate key error while creating payment order")
        if "participantId_1" in str(exc) or "participant_id_1" in str(exc):
            raise HTTPException(
                status_code=500,
                detail=(
                    "Database index conflict on participant_id. "
                    "This usually happens if older uniqueness constraints are still active. "
                    "Please restart the server to run the database cleanup scripts."
                ),
            )
        raise HTTPException(status_code=409, detail="A unique constraint error occurred. Please try again.")
    except Exception as exc:
        logger.exception("Unexpected error in create_order")
        raise HTTPException(status_code=500, detail="An internal error occurred while processing the payment order.")
