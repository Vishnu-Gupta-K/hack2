import logging
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from app.core.logging_utils import configure_logging
from app.core.time_utils import ist_timestamp
from app.database.mongodb import initialize_async_collections
from app.routers import auth, colleges, payments, students, teams, tasks
from config.settings import get_settings

settings = get_settings()

configure_logging(level=logging.INFO)


@asynccontextmanager
async def lifespan(_: FastAPI):
    await initialize_async_collections()
    yield


app = FastAPI(title=settings.app_name, lifespan=lifespan)

app.add_middleware(
    SessionMiddleware,
    secret_key=settings.secret_key,
    same_site="lax",
    https_only=settings.is_production,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(_: Request, exc: Exception):
    logging.getLogger("app").exception("Unhandled exception: %s", exc)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "timestamp": ist_timestamp(),
        },
    )


@app.get("/api/health")
def health_check():
    return {
        "status": "running",
        "timestamp": ist_timestamp(),
        "environment": settings.app_env,
        "timezone": "Asia/Kolkata",
    }


app.include_router(auth.router)
app.include_router(colleges.router)
app.include_router(payments.router)
app.include_router(students.router)
app.include_router(teams.router)
app.include_router(tasks.router)

# Serve static files at root
static_app = StaticFiles(directory="static", html=True)

async def static_handler(scope, receive, send):
    if scope["type"] != "http":
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1000})
        return
    await static_app(scope, receive, send)

app.mount("/", static_handler, name="static")


if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.server_host, port=settings.server_port, reload=False)
