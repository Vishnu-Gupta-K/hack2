# Spheronix Hackathon 2026 - AWS EC2 Production Deployment Guide

This guide is written for the current codebase in this repository (FastAPI + MongoDB + Google OAuth + Cashfree + static frontend served by FastAPI).

It covers full deployment from zero to go-live, including OAuth registration details and production hardening.

## 1. Production Architecture (Current Project)

- App entrypoint: `app/main.py`
- API + static hosting: same process (`app.mount("/", StaticFiles(...))`)
- Auth callback: `/api/auth/callback`
- Payment endpoints: `/api/payment/order`, `/api/payment/verify`, `/api/payment/webhook`
- Health endpoint: `/api/health`
- Process model: Gunicorn + Uvicorn worker (`scripts/start.sh`)
- Service file template: `scripts/hackathon.service`

Recommended production stack:

1. AWS EC2 Ubuntu 22.04 server
2. Nginx reverse proxy on ports 80/443
3. Gunicorn app bound to `127.0.0.1:8000`
4. MongoDB Atlas (recommended) or secured self-hosted MongoDB
5. HTTPS via Let's Encrypt

## 2. Prerequisites

Before deployment, keep these ready:

- Domain name (example: `hackathon.yourdomain.com`)
- EC2 Elastic IP
- MongoDB production URI and DB name
- Google OAuth credentials
- Cashfree production credentials
- SMTP credentials (optional but recommended for confirmation emails)

## 3. AWS EC2 Setup (Console Steps)

### 3.1 Launch EC2 instance

1. Open AWS Console -> EC2 -> `Launch instance`.
2. Name: `hackathon-prod`.
3. AMI: `Ubuntu Server 22.04 LTS`.
4. Instance type: `t3.small` minimum recommended (`t2.micro` only for light traffic/testing).
5. Key pair: create/select one (`.pem`) and keep it secure.
6. Network: choose default VPC/subnet or your production VPC.
7. Auto-assign public IP: enabled.
8. Storage: 20 GB gp3 minimum recommended.

### 3.2 Security Group rules

Create/attach a security group with inbound rules:

- `SSH` TCP `22` from your office/home IP only (not `0.0.0.0/0`)
- `HTTP` TCP `80` from `0.0.0.0/0`
- `HTTPS` TCP `443` from `0.0.0.0/0`

### 3.3 Allocate and attach Elastic IP

1. EC2 -> Elastic IPs -> `Allocate Elastic IP`.
2. Associate it to `hackathon-prod` instance.
3. Use this Elastic IP in DNS records and third-party allowlists (Cashfree).

### 3.4 Connect to EC2 via SSH

```bash
chmod 400 <your-key>.pem
ssh -i <your-key>.pem ubuntu@<EC2_ELASTIC_IP>
```

### 3.5 Optional but recommended EC2 hardening

- Enable CloudWatch agent/log shipping.
- Enable AWS Systems Manager (SSM) for managed access.
- Enable EBS encryption and snapshot policy.

## 4. EC2 OS Bootstrap

### 4.1 Install base packages

```bash
sudo apt update ; sudo apt upgrade -y
sudo apt install -y python3 python3-pip python3-venv git nginx
```

### 4.2 Create app user and directory

```bash
sudo adduser --disabled-password --gecos "" hackathon
sudo mkdir -p /opt/hackathon
sudo chown -R hackathon:hackathon /opt/hackathon
```

## 5. Deploy Code

```bash
sudo -u hackathon -H bash -lc 'cd /opt/hackathon ; git clone <YOUR_REPO_URL> app'
sudo -u hackathon -H bash -lc 'cd /opt/hackathon/app ; python3 -m venv venv ; source venv/bin/activate ; pip install --upgrade pip ; pip install -r requirements.txt'
```

## 6. Create Production `.env`

This project reads env from `.env` using `config/settings.py`.

Create `/opt/hackathon/app/.env`:

```env
APP_ENV=production
SERVER_HOST=127.0.0.1
SERVER_PORT=8000

MONGODB_URI=mongodb+srv://<user>:<pass>@<cluster>/<dbname>?retryWrites=true&w=majority
DATABASE_NAME=hackathon_db

CORS_ORIGINS=https://hackathon.yourdomain.com,https://www.hackathon.yourdomain.com

SECRET_KEY=<LONG_RANDOM_SECRET>
GOOGLE_CLIENT_ID=<GOOGLE_CLIENT_ID>
GOOGLE_CLIENT_SECRET=<GOOGLE_CLIENT_SECRET>
GOOGLE_REDIRECT_URI=https://hackathon.yourdomain.com/api/auth/callback

CASHFREE_APP_ID=<CASHFREE_APP_ID>
CASHFREE_SECRET_KEY=<CASHFREE_SECRET_KEY>
CASHFREE_ENVIRONMENT=PRODUCTION
CASHFREE_ALLOW_MOCK_ON_BLOCK=false

SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=<SMTP_USER>
SMTP_PASSWORD=<SMTP_PASSWORD>
MAIL_FROM=<MAIL_FROM_ADDRESS>

WORKERS=2
```

Set secure permissions:

```bash
sudo chown hackathon:hackathon /opt/hackathon/app/.env
sudo chmod 600 /opt/hackathon/app/.env
```

Notes:

- `CORS_ORIGINS` must include the exact HTTPS frontend domains.
- Keep `CASHFREE_ALLOW_MOCK_ON_BLOCK=false` in production.
- Do not use localhost redirect URI in production.

## 7. Register Google OAuth (Required)

This code uses Google OpenID Connect and calls `/api/auth/callback`.

### 7.1 Create project and OAuth client

1. Go to Google Cloud Console.
2. Create/select project.
3. Configure OAuth consent screen.
4. Create OAuth Client ID of type `Web application`.

### 7.2 Authorized Origins

Add:

- `https://hackathon.yourdomain.com`
- `https://www.hackathon.yourdomain.com` (if used)

### 7.3 Authorized Redirect URIs

Add exactly:

- `https://hackathon.yourdomain.com/api/auth/callback`

### 7.4 Put values in `.env`

- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REDIRECT_URI`

## 8. Register Cashfree Production Credentials

### 8.1 Create/Use Cashfree merchant account

Collect:

- `CASHFREE_APP_ID`
- `CASHFREE_SECRET_KEY`

Set `CASHFREE_ENVIRONMENT=PRODUCTION`.

### 8.2 Configure webhook endpoint in Cashfree dashboard

Set webhook URL to:

- `https://hackathon.yourdomain.com/api/payment/webhook`

The backend verifies signature from `x-webhook-signature` using `CASHFREE_SECRET_KEY`.

### 8.3 Cashfree IP allowlisting

If your Cashfree account enforces IP allowlist, add server public IP in Cashfree settings.

## 9. Configure systemd Service

Create `/etc/systemd/system/hackathon.service`:

```ini
[Unit]
Description=Spheronix Hackathon FastAPI Service
After=network.target

[Service]
Type=simple
User=hackathon
Group=www-data
WorkingDirectory=/opt/hackathon/app
EnvironmentFile=/opt/hackathon/app/.env
ExecStart=/opt/hackathon/app/venv/bin/gunicorn -k uvicorn.workers.UvicornWorker --workers ${WORKERS:-2} --bind 127.0.0.1:8000 --timeout 120 --access-logfile - --error-logfile - app.main:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl daemon-reload
sudo systemctl enable hackathon
sudo systemctl start hackathon
sudo systemctl status hackathon
```

Live logs:

```bash
sudo journalctl -u hackathon -f
```

## 10. Configure Nginx Reverse Proxy

Create `/etc/nginx/sites-available/hackathon`:

```nginx
server {
    listen 80;
    server_name hackathon.yourdomain.com www.hackathon.yourdomain.com;

    client_max_body_size 10M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable site:

```bash
sudo ln -sf /etc/nginx/sites-available/hackathon /etc/nginx/sites-enabled/hackathon
sudo nginx -t
sudo systemctl restart nginx
```

## 11. Enable HTTPS (Let's Encrypt)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d hackathon.yourdomain.com -d www.hackathon.yourdomain.com
```

Check renewal timer:

```bash
sudo systemctl status certbot.timer
```

## 12. DNS Setup (Route 53 or Any DNS Provider)

If you use Route 53:

1. Open Route 53 -> Hosted zones -> your domain.
2. Create `A` record for `hackathon` pointing to EC2 Elastic IP.
3. Create `A` record for `www.hackathon` (optional) pointing to same Elastic IP.

Then configure the same hostnames in:

- Nginx `server_name`
- Google OAuth origins + redirect URI
- Cashfree webhook URL

Create `A` records:

- `hackathon.yourdomain.com -> <SERVER_PUBLIC_IP>`
- `www.hackathon.yourdomain.com -> <SERVER_PUBLIC_IP>` (optional)

Wait for DNS propagation before SSL issuance.

## 13. Production Validation Checklist

### 13.1 API and UI

- Open `https://hackathon.yourdomain.com`
- Verify static frontend loads
- Verify `https://hackathon.yourdomain.com/api/health`

### 13.2 OAuth flow

- Click Google login button
- Complete consent
- Ensure popup returns success and closes
- Ensure user document exists in MongoDB `users` collection

### 13.3 Payment flow

- Create payment order (`/api/payment/order`)
- Complete checkout
- Verify `/api/payment/verify` success
- Confirm `/api/register` stores registration and payment records
- Confirm webhook delivery success in Cashfree dashboard

### 13.4 Registration quality checks

- Validate team registration allows total 2 to 5 members including leader
- Validate terms acceptance is mandatory before moving to payment step
- Validate confirmation email delivery includes team name, transaction ID, amount, status, and date

### 13.5 Email inbox delivery checks

- Confirm `MAIL_FROM` domain matches `SMTP_USER` domain.
- Verify SPF record exists and includes your SMTP provider.
- Verify DKIM is enabled in provider dashboard and DNS key is published.
- Verify DMARC record exists for same sending domain.
- Send a test mail to Gmail and inspect headers for `spf=pass`, `dkim=pass`, `dmarc=pass`.
- If Gmail still classifies as spam, warm up domain and keep consistent sender identity.

## 14. First-Run Security Actions (Important)

1. Keep `.env` secrets rotated and private.
2. Restrict database and SMTP credentials to least privilege.
3. Confirm no wildcard CORS is used in production.

Also ensure:

- No wildcard CORS in production.
- SSH is key-based (disable password login).
- Automatic security updates enabled.

## 15. Zero-Downtime Update Procedure

```bash
sudo -u hackathon -H bash -lc 'cd /opt/hackathon/app ; git fetch ; git pull --ff-only ; source venv/bin/activate ; pip install -r requirements.txt'
sudo systemctl restart hackathon
sudo systemctl status hackathon --no-pager
```

Post-deploy smoke test:

- `/api/health`
- OAuth login
- One payment and registration test
- Admin login and stats

## 16. Quick Troubleshooting

- Service fails to start: `sudo journalctl -u hackathon -n 200 --no-pager`
- Nginx errors: `sudo tail -n 200 /var/log/nginx/error.log`
- OAuth `redirect_uri_mismatch`: fix `GOOGLE_REDIRECT_URI` and Google console redirect URI
- Cashfree 403 IP issue: allowlist server public IP in Cashfree dashboard
- Registration blocked by duplicate index: verify unique fields (`email`, `mobile`, `rollNumber`, `cf_order_id`)

## 17. Minimal Go-Live Command Summary

```bash
sudo systemctl restart hackathon
sudo systemctl restart nginx
curl -sS https://hackathon.yourdomain.com/api/health
sudo journalctl -u hackathon -n 100 --no-pager
```

If health is green and full flow tests pass, production is ready.
