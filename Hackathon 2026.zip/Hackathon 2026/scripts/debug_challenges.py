import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from config.settings import get_settings

async def check():
    s = get_settings()
    print(f"Connecting to: {s.effective_mongodb_uri}")
    print(f"Database: {s.effective_database_name}")
    c = AsyncIOMotorClient(s.effective_mongodb_uri)
    db = c[s.effective_database_name]
    col = db['hackathon_challenges']
    count = await col.count_documents({})
    cats = await col.distinct('category')
    print(f"Count: {count}")
    print(f"Categories: {cats}")
    
    if count > 0:
        one = await col.find_one()
        print(f"Sample: {one}")

if __name__ == "__main__":
    asyncio.run(check())
