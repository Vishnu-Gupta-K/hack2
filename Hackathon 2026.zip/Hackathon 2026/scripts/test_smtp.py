import smtplib
import ssl
import os
from dotenv import load_dotenv

# Load .env
load_dotenv('f:/Spheronix/Mansoor Sir Tasks/Hackathon 2026/.env')

smtp_host = os.getenv('SMTP_HOST')
smtp_port = int(os.getenv('SMTP_PORT', 587))
smtp_user = os.getenv('SMTP_USER')
smtp_password = os.getenv('SMTP_PASSWORD')
mail_from = os.getenv('MAIL_FROM')

print(f"Testing SMTP with {smtp_host}:{smtp_port}")
print(f"User: {smtp_user}")

try:
    print(f"Testing SMTP_SSL with {smtp_host}:465")
    with smtplib.SMTP_SSL(smtp_host, 465, timeout=10) as server:
        server.login(smtp_user, smtp_password)
        print("Login SUCCESSFUL")
        
        # Try to send a test email
        message = "Subject: SMTP Test 465\n\nThis is a test email over 465."
        server.sendmail(mail_from, [smtp_user], message)
        print("Test email sent successfully to", smtp_user)
except Exception as e:
    print(f"Error 465: {e}")

