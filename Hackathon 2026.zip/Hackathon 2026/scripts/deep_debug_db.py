import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from config.settings import get_settings

async def check():
    s = get_settings()
    c = AsyncIOMotorClient(s.effective_mongodb_uri)
    
    for db_name in ["spheronix_db", "HackathonSpheronixGlobal"]:
        db = c[db_name]
        print(f"--- Database: {db_name} ---")
        collections = await db.list_collection_names()
        print(f"Collections: {collections}")
        for col_name in collections:
            count = await db[col_name].count_documents({})
            print(f"  {col_name}: {count} docs")
            if col_name == "hackathon_challenges":
                cats = await db[col_name].distinct("category")
                print(f"    Categories: {cats}")

if __name__ == "__main__":
    asyncio.run(check())
