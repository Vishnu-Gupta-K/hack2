import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from config.settings import get_settings

async def check():
    s = get_settings()
    print(f"Settings DB_NAME: {s.database_name}")
    print(f"Settings Effective DB: {s.effective_database_name}")
    print(f"Settings URI: {s.effective_mongodb_uri[:50]}...")
    
    print("Environment Variables:")
    print(f"MONGO_URI from os.environ: {os.environ.get('MONGO_URI')}")
    print(f"DB_NAME from os.environ: {os.environ.get('DB_NAME')}")
    
    c = AsyncIOMotorClient(s.effective_mongodb_uri)
    
    for db_name in ["spheronix_db", "hackathon_db"]:
        db = c[db_name]
        col = db['hackathon_challenges']
        count = await col.count_documents({})
        print(f"Database: {db_name}, hackathon_challenges count: {count}")
        if count > 0:
            cats = await col.distinct('category')
            print(f"  Categories: {cats}")

if __name__ == "__main__":
    asyncio.run(check())
