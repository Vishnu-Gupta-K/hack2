import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from config.settings import get_settings

async def inspect():
    settings = get_settings()
    client = AsyncIOMotorClient(settings.effective_mongodb_uri)
    db = client["HackathonSpheronixGlobal"]
    col = db["global data"]
    
    docs = await col.find({}).to_list(length=100)
    for doc in docs:
        print(f"Name: {doc.get('name')}")
        print(f"Questions: {doc.get('questions')}")
        print("-" * 20)

if __name__ == "__main__":
    asyncio.run(inspect())
