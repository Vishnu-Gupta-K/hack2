import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from config.settings import get_settings

CHALLENGES = [
    # BUG Category
    {
        "category": "BUG",
        "title": "BUG1",
        "description": "Debug a pharmacy management web application containing four intentional bugs: Paracetamol bundle pricing anomaly, Cetirizine infinite stock glitch, regulated medicine validation bypass, and admin inventory UI obfuscation.",
        "difficulty": "medium",
    },
    {
        "category": "BUG",
        "title": "BUG2",
        "description": "Debug a bus ticket booking application containing one intentional logic bug.",
        "difficulty": "easy",
    },
    {
        "category": "BUG",
        "title": "BUG3",
        "description": "Identify and fix bugs in a hackathon management application.",
        "difficulty": "medium",
    },
    # WEB Category
    {
        "category": "WEB",
        "title": "WEB1",
        "description": "Build a web attendance system where the QR changes every 30 seconds and students mark attendance using webcam scanning.",
        "difficulty": "hard",
    },
    {
        "category": "WEB",
        "title": "WEB2",
        "description": "Build a web emergency alert system where users trigger an SOS alert and responders are notified.",
        "difficulty": "medium",
    },
    {
        "category": "WEB",
        "title": "WEB3",
        "description": "Create a platform connecting restaurants and NGOs to reduce food waste.",
        "difficulty": "medium",
    },
    # APP Category
    {
        "category": "APP",
        "title": "APP1",
        "description": "Build an Android app that fetches and displays Spheronix Technology website data using APIs. Must consume APIs and must not use WebView.",
        "difficulty": "medium",
    },
    {
        "category": "APP",
        "title": "APP2",
        "description": "Build a Windows utility in C++ that reads battery data using Windows APIs, analyzes battery health, and generates a diagnostic report.",
        "difficulty": "hard",
    },
    {
        "category": "APP",
        "title": "APP3",
        "description": "Develop a mobile application for real-time task management and collaboration.",
        "difficulty": "medium",
    }
]

async def seed_challenges():
    settings = get_settings()
    client = AsyncIOMotorClient(settings.effective_mongodb_uri)
    db = client[settings.effective_database_name]
    col = db["hackathon_challenges"]
    
    await col.delete_many({})
    await col.insert_many(CHALLENGES)
    print(f"Successfully seeded {len(CHALLENGES)} challenges into {settings.effective_database_name}.hackathon_challenges")

if __name__ == "__main__":
    asyncio.run(seed_challenges())
