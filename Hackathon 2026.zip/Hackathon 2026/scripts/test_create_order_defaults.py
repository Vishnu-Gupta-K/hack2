import asyncio
import secrets
from app.services.payment_service import create_order
from app.models.schemas import PaymentOrderRequest
from app.database.mongodb import registrations_async_collection

async def test():
    # 1. Clear a test email
    email = f"test_{secrets.token_hex(4)}@example.com"
    await registrations_async_collection.delete_many({"email": email})

    # 2. Create order
    req = PaymentOrderRequest(
        fullName="Test User",
        email=email,
        mobile="9999999999",
        participationMode="individual",
        teamMembersCount=0,
        projectSelected="Test Project"
    )
    print("Creating order...")
    resp = await create_order(req)
    
    # 3. Fetch from DB
    doc = await registrations_async_collection.find_one({"email": email})
    print("\nDocument after initial create_order:")
    for k, v in doc.items():
        if k not in ['_id', 'payment']:
            print(f"  {k}: {v}")
    
    if "is_reviewed" in doc:
        print("SUCCESS: is_reviewed is present in the new document!")
    else:
        print("FAIL: is_reviewed is missing!")

if __name__ == "__main__":
    asyncio.run(test())
