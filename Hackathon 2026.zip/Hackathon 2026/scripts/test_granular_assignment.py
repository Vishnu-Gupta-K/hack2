import asyncio
import random
from motor.motor_asyncio import AsyncIOMotorClient
from config.settings import get_settings
from app.services.challenge_service import assign_random_challenge
from app.database.mongodb import registrations_async_collection

async def test_assignment():
    settings = get_settings()
    # Test assignment logic
    category = "BUG"
    challenge = await assign_random_challenge(category)
    print(f"Assigned for {category}: {challenge['title']}")
    
    if challenge['title'] not in ["BUG1", "BUG2", "BUG3"]:
        print(f"FAILED: Expected BUG1/2/3, got {challenge['title']}")
    else:
        print("PASSED: Correct granular task assigned")

if __name__ == "__main__":
    asyncio.run(test_assignment())
